# Deployment Instructions for Offline GitLab Repository

This package contains all necessary files to deploy the Regex Tester application to an offline GitLab instance.

## Quick Start

1. **Extract the package** to your local machine
2. **Initialize Git repository** (if not already done):
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Regex Tester v1.0.0"
   ```

3. **Add your GitLab remote**:
   ```bash
   git remote add origin git@your-gitlab-instance.com:your-username/regex-tester.git
   ```

4. **Push to GitLab**:
   ```bash
   git push -u origin main
   ```

## GitLab Pages Setup

The `.gitlab-ci.yml` file is already configured for automatic deployment. Once you push to your GitLab repository:

1. The CI/CD pipeline will automatically run
2. GitLab Pages will be deployed
3. Access your app at: `https://your-username.your-gitlab-instance.com/regex-tester`

## Manual Deployment Options

### Option 1: Direct File Access
Simply open `index.html` in any modern web browser. No server required!

### Option 2: Local Web Server
```bash
# Using Python 3
python3 -m http.server 8000

# Using Python 2
python -m SimpleHTTPServer 8000

# Using npm (after npm install)
npm start
```

### Option 3: Web Server Deployment
Upload all files to your web server's document root. The application is entirely client-side and requires no server-side processing.

## File Structure

```
regex-tester/
├── index.html          # Main application
├── app.js              # Core logic
├── mode-help.js        # Help content
├── themes/             # 14 theme files
├── favicon.ico         # Browser favicon
├── favicon.svg         # SVG favicon
├── favicon-*.png       # PNG favicons (multiple sizes)
├── manifest.json       # Web app manifest
├── package.json        # NPM metadata
├── README.md           # Documentation
├── LICENSE             # ISC License
├── .gitlab-ci.yml      # GitLab CI/CD
├── _config.yml         # GitHub Pages config
├── 404.html            # 404 redirect page
└── DEPLOYMENT.md       # This file
```

## Requirements

- Modern web browser (Chrome 70+, Firefox 78+, Safari 12+)
- No backend dependencies
- No build process required
- Works completely offline once loaded

## Customization

To customize for your organization:

1. Update `package.json` with your details
2. Modify `README.md` with your repository URLs
3. Adjust `.gitlab-ci.yml` if needed for your CI/CD setup
4. Replace favicon files with your own branding

## Progressive Web App Support

The application includes:
- Web app manifest for installability
- Multiple favicon sizes for different devices
- Theme color configuration
- Standalone display mode

Users can install the app on their devices for an app-like experience.

## Support

For issues or questions, please refer to the README.md file or create an issue in your GitLab repository.