// Quick syntax verification script
// Checks that all JavaScript files have valid syntax

const fs = require('fs');
const path = require('path');

const jsFiles = [
    'app.js',
    'mode-help.js',
    'regex-parser.js',
    'syntax-highlighter.js',
    'pattern-explainer.js',
    'enhanced-tooltips.js',
    'replacement-preview.js',
    'pattern-library.js',
    'test-features.js'
];

console.log('🔍 Verifying JavaScript syntax...\n');

let hasErrors = false;

jsFiles.forEach(file => {
    try {
        const filePath = path.join(__dirname, file);
        const content = fs.readFileSync(filePath, 'utf8');
        
        // Try to parse the JavaScript
        new Function(content);
        
        console.log(`✅ ${file} - Valid syntax`);
    } catch (error) {
        hasErrors = true;
        console.log(`❌ ${file} - Syntax error:`);
        console.log(`   ${error.message}`);
    }
});

console.log('\n' + '='.repeat(50));
if (!hasErrors) {
    console.log('✅ All JavaScript files have valid syntax!');
} else {
    console.log('❌ Some files have syntax errors. Please fix them.');
    process.exit(1);
}