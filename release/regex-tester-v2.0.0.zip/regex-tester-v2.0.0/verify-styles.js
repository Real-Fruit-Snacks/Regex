// Style Consistency Verification Script
// Checks that all new features use the design system colors

const fs = require('fs');
const path = require('path');

console.log('🎨 Verifying Style Consistency...\n');

// Design system colors
const designSystemColors = {
    // Primary colors
    '#3498db': 'Primary Blue',
    '#2980b9': 'Dark Blue',
    '#2c3e50': 'Dark Gray',
    '#34495e': 'Medium Gray',
    '#7f8c8d': 'Light Gray', 
    '#95a5a6': 'Silver',
    '#ecf0f1': 'Light Background',
    '#bdc3c7': 'Light Text',
    
    // Accent colors
    '#e74c3c': 'Error Red',
    '#c0392b': 'Dark Red',
    '#27ae60': 'Success Green',
    '#229954': 'Dark Green',
    '#f39c12': 'Warning Orange',
    '#f1c40f': 'Yellow',
    '#8e44ad': 'Purple',
    '#9b59b6': 'Light Purple',
    '#16a085': 'Teal',
    '#1abc9c': 'Turquoise',
    
    // Neutrals
    '#ffffff': 'White',
    '#000000': 'Black',
    '#ddd': 'Border Gray',
    '#eee': 'Very Light Gray'
};

// Bootstrap colors that should NOT be used
const bootstrapColors = [
    '#007bff', '#0056b3', // Bootstrap blue
    '#28a745', '#218838', // Bootstrap green
    '#dc3545', '#c82333', // Bootstrap red
    '#ffc107', '#e0a800', // Bootstrap yellow
    '#17a2b8', '#117a8b', // Bootstrap info
    '#6c757d', '#545b62', // Bootstrap secondary
    '#f8f9fa', '#e9ecef', // Bootstrap light grays
    '#dee2e6', '#ced4da', // Bootstrap borders
    '#495057', '#343a40', // Bootstrap dark grays
    '#212529'             // Bootstrap darkest
];

// Files to check
const filesToCheck = [
    'syntax-highlighter.js',
    'pattern-explainer.js',
    'enhanced-tooltips.js',
    'replacement-preview.js',
    'pattern-library.js'
];

let issuesFound = 0;

filesToCheck.forEach(file => {
    console.log(`\nChecking ${file}...`);
    const filePath = path.join(__dirname, file);
    const content = fs.readFileSync(filePath, 'utf8');
    
    // Check for Bootstrap colors
    let foundBootstrap = false;
    bootstrapColors.forEach(color => {
        const regex = new RegExp(color.replace('#', '#?'), 'gi');
        const matches = content.match(regex);
        if (matches) {
            console.log(`  ❌ Found Bootstrap color ${color} (${matches.length} times)`);
            foundBootstrap = true;
            issuesFound++;
        }
    });
    
    // Check for non-standard border radius
    const borderRadiusRegex = /border-radius:\s*(\d+)px/g;
    let match;
    while ((match = borderRadiusRegex.exec(content)) !== null) {
        const radius = parseInt(match[1]);
        if (radius !== 4 && radius !== 8) {
            console.log(`  ⚠️  Non-standard border-radius: ${radius}px at position ${match.index}`);
            issuesFound++;
        }
    }
    
    // Check for non-standard padding/margins
    const spacingRegex = /(padding|margin):\s*(\d+)px/g;
    while ((match = spacingRegex.exec(content)) !== null) {
        const spacing = parseInt(match[2]);
        if (spacing !== 0 && spacing !== 5 && spacing !== 10 && spacing !== 15 && spacing !== 20 && spacing !== 30 && spacing !== 40) {
            console.log(`  ⚠️  Non-standard ${match[1]}: ${spacing}px at position ${match.index}`);
        }
    }
    
    if (!foundBootstrap) {
        console.log(`  ✅ No Bootstrap colors found`);
    }
});

console.log('\n' + '='.repeat(50));
if (issuesFound === 0) {
    console.log('✅ All files follow the design system!');
} else {
    console.log(`⚠️  Found ${issuesFound} style consistency issues`);
}

// Check for theme variables usage
console.log('\n📊 CSS Variable Usage Check:');
let usesVariables = false;

filesToCheck.forEach(file => {
    const filePath = path.join(__dirname, file);
    const content = fs.readFileSync(filePath, 'utf8');
    
    if (content.includes('var(--') || content.includes('currentColor')) {
        console.log(`  ✅ ${file} uses CSS variables or currentColor`);
        usesVariables = true;
    }
});

if (!usesVariables) {
    console.log('  ⚠️  Consider using CSS variables for better theme support');
}