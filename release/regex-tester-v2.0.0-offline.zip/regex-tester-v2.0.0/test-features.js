// Comprehensive Feature Testing Suite
// Tests all new regex tester features

class FeatureTester {
    constructor() {
        this.results = {
            parser: { passed: 0, failed: 0, tests: [] },
            highlighter: { passed: 0, failed: 0, tests: [] },
            explainer: { passed: 0, failed: 0, tests: [] },
            tooltips: { passed: 0, failed: 0, tests: [] },
            replacement: { passed: 0, failed: 0, tests: [] },
            library: { passed: 0, failed: 0, tests: [] }
        };
    }

    // Test runner
    async runAllTests() {
        console.log('🧪 Starting comprehensive feature tests...\n');
        
        await this.testParser();
        await this.testSyntaxHighlighter();
        await this.testPatternExplainer();
        await this.testEnhancedTooltips();
        await this.testReplacementPreview();
        await this.testPatternLibrary();
        
        this.displayResults();
    }

    // 1. Test Regex Parser
    async testParser() {
        console.log('📝 Testing Regex Parser...');
        const parser = new RegexParser();
        
        const testCases = [
            // Basic patterns
            { pattern: 'abc', mode: 'javascript', expected: { tokenCount: 3, hasErrors: false } },
            { pattern: 'a+b*c?', mode: 'javascript', expected: { tokenCount: 6, hasErrors: false } },
            
            // Groups
            { pattern: '(abc)', mode: 'javascript', expected: { tokenCount: 5, hasErrors: false } },
            { pattern: '(?:abc)', mode: 'javascript', expected: { tokenCount: 6, hasErrors: false } },
            { pattern: '(?<name>\\d+)', mode: 'javascript', expected: { tokenCount: 8, hasErrors: false } },
            
            // Character classes
            { pattern: '[a-z]', mode: 'javascript', expected: { tokenCount: 5, hasErrors: false } },
            { pattern: '[^0-9]', mode: 'javascript', expected: { tokenCount: 6, hasErrors: false } },
            
            // Escapes
            { pattern: '\\d+\\s*\\w', mode: 'javascript', expected: { tokenCount: 5, hasErrors: false } },
            { pattern: '\\x41\\u0042\\n', mode: 'javascript', expected: { tokenCount: 3, hasErrors: false } },
            
            // Assertions
            { pattern: '^start$', mode: 'javascript', expected: { tokenCount: 7, hasErrors: false } },
            { pattern: '\\bhello\\b', mode: 'javascript', expected: { tokenCount: 7, hasErrors: false } },
            { pattern: 'a(?=b)(?!c)', mode: 'javascript', expected: { tokenCount: 9, hasErrors: false } },
            
            // Mode-specific tests
            { pattern: '\\(group\\)', mode: 'grep', expected: { tokenCount: 8, hasErrors: false } },
            { pattern: '(?P<name>\\d+)', mode: 'python', expected: { tokenCount: 9, hasErrors: false } },
            { pattern: '\\vvery\\+magic', mode: 'vim', expected: { tokenCount: 12, hasErrors: false } },
            
            // Error cases
            { pattern: '(unclosed', mode: 'javascript', expected: { hasErrors: true } },
            { pattern: '[unclosed', mode: 'javascript', expected: { hasErrors: true } }
        ];

        for (const test of testCases) {
            try {
                const result = parser.parse(test.pattern, test.mode);
                const passed = 
                    (test.expected.tokenCount === undefined || result.tokens.length === test.expected.tokenCount) &&
                    (test.expected.hasErrors === (result.errors.length > 0));
                
                this.results.parser[passed ? 'passed' : 'failed']++;
                this.results.parser.tests.push({
                    pattern: test.pattern,
                    mode: test.mode,
                    passed,
                    actual: { tokenCount: result.tokens.length, hasErrors: result.errors.length > 0 },
                    expected: test.expected
                });
            } catch (e) {
                this.results.parser.failed++;
                this.results.parser.tests.push({
                    pattern: test.pattern,
                    mode: test.mode,
                    passed: false,
                    error: e.message
                });
            }
        }
    }

    // 2. Test Syntax Highlighter
    async testSyntaxHighlighter() {
        console.log('🎨 Testing Syntax Highlighter...');
        
        // Create test container
        const testContainer = document.createElement('div');
        testContainer.innerHTML = `
            <input type="text" id="test-regex-input" style="width: 300px;">
        `;
        document.body.appendChild(testContainer);
        
        const input = document.getElementById('test-regex-input');
        const highlighter = new PatternHighlighter(input);
        
        const testCases = [
            { pattern: '(abc)+', expectedHighlights: ['group', 'literal', 'literal', 'literal', 'group', 'quantifier'] },
            { pattern: '\\d{2,4}', expectedHighlights: ['escape', 'quantifier', 'quantifier', 'quantifier', 'quantifier', 'quantifier'] },
            { pattern: '[a-z]+', expectedHighlights: ['char-class', 'char-class', 'char-class', 'char-class', 'char-class', 'quantifier'] },
            { pattern: '^test$', expectedHighlights: ['anchor', 'literal', 'literal', 'literal', 'literal', 'anchor'] }
        ];

        for (const test of testCases) {
            try {
                input.value = test.pattern;
                const tokens = await highlighter.highlight(test.pattern);
                const passed = tokens !== null && tokens.length > 0;
                
                this.results.highlighter[passed ? 'passed' : 'failed']++;
                this.results.highlighter.tests.push({
                    pattern: test.pattern,
                    passed,
                    tokenCount: tokens ? tokens.length : 0
                });
            } catch (e) {
                this.results.highlighter.failed++;
                this.results.highlighter.tests.push({
                    pattern: test.pattern,
                    passed: false,
                    error: e.message
                });
            }
        }
        
        // Cleanup
        document.body.removeChild(testContainer);
    }

    // 3. Test Pattern Explainer
    async testPatternExplainer() {
        console.log('📖 Testing Pattern Explainer...');
        
        const parser = new RegexParser();
        const explainer = new PatternExplainer();
        
        const testCases = [
            { pattern: 'abc', expectedExplanations: 3 },
            { pattern: '(\\d+)', expectedExplanations: 3 }, // group + escape + quantifier
            { pattern: '[a-z]+', expectedExplanations: 2 }, // char class + quantifier
            { pattern: '^test$', expectedExplanations: 3 }, // anchor + literals + anchor
            { pattern: 'a(?=b)', expectedExplanations: 2 } // literal + lookahead
        ];

        for (const test of testCases) {
            try {
                const parseResult = parser.parse(test.pattern, 'javascript');
                const explanations = explainer.generateExplanations(parseResult.ast, 'javascript');
                const passed = explanations.length >= test.expectedExplanations;
                
                this.results.explainer[passed ? 'passed' : 'failed']++;
                this.results.explainer.tests.push({
                    pattern: test.pattern,
                    passed,
                    explanationCount: explanations.length,
                    expected: test.expectedExplanations
                });
            } catch (e) {
                this.results.explainer.failed++;
                this.results.explainer.tests.push({
                    pattern: test.pattern,
                    passed: false,
                    error: e.message
                });
            }
        }
    }

    // 4. Test Enhanced Tooltips
    async testEnhancedTooltips() {
        console.log('💡 Testing Enhanced Tooltips...');
        
        const tooltips = new EnhancedTooltips();
        
        const testCases = [
            { tokenType: 'escape', tokenValue: '\\d', mode: 'javascript' },
            { tokenType: 'quantifier', tokenValue: '+', mode: 'javascript' },
            { tokenType: 'group', tokenValue: '(', mode: 'javascript' },
            { tokenType: 'char-class', tokenValue: '[', mode: 'javascript' },
            { tokenType: 'anchor', tokenValue: '^', mode: 'javascript' }
        ];

        for (const test of testCases) {
            try {
                const content = tooltips.getTooltipContent(test.tokenType, test.tokenValue, test.mode);
                const passed = content && content.title && content.description;
                
                this.results.tooltips[passed ? 'passed' : 'failed']++;
                this.results.tooltips.tests.push({
                    tokenType: test.tokenType,
                    tokenValue: test.tokenValue,
                    passed,
                    hasContent: !!content
                });
            } catch (e) {
                this.results.tooltips.failed++;
                this.results.tooltips.tests.push({
                    tokenType: test.tokenType,
                    tokenValue: test.tokenValue,
                    passed: false,
                    error: e.message
                });
            }
        }
    }

    // 5. Test Replacement Preview
    async testReplacementPreview() {
        console.log('🔄 Testing Replacement Preview...');
        
        const preview = new ReplacementPreview();
        
        const testCases = [
            {
                text: 'Hello World',
                pattern: 'Hello',
                replacement: 'Hi',
                flags: 'g',
                expectedResult: 'Hi World'
            },
            {
                text: 'test@example.com',
                pattern: '(\\w+)@(\\w+\\.\\w+)',
                replacement: '$1 at $2',
                flags: 'g',
                expectedResult: 'test at example.com'
            },
            {
                text: 'John Doe',
                pattern: '(?<first>\\w+) (?<last>\\w+)',
                replacement: '$<last>, $<first>',
                flags: 'g',
                expectedResult: 'Doe, John'
            },
            {
                text: '123-456-7890',
                pattern: '(\\d{3})-(\\d{3})-(\\d{4})',
                replacement: '($1) $2-$3',
                flags: 'g',
                expectedResult: '(123) 456-7890'
            }
        ];

        for (const test of testCases) {
            try {
                const result = preview.performReplacement(
                    test.text,
                    test.pattern,
                    test.replacement,
                    test.flags,
                    'javascript'
                );
                const passed = result.output === test.expectedResult;
                
                this.results.replacement[passed ? 'passed' : 'failed']++;
                this.results.replacement.tests.push({
                    pattern: test.pattern,
                    passed,
                    actual: result.output,
                    expected: test.expectedResult
                });
            } catch (e) {
                this.results.replacement.failed++;
                this.results.replacement.tests.push({
                    pattern: test.pattern,
                    passed: false,
                    error: e.message
                });
            }
        }
    }

    // 6. Test Pattern Library
    async testPatternLibrary() {
        console.log('📚 Testing Pattern Library...');
        
        const library = new PatternLibrary();
        
        // Test categories exist
        const categories = Object.keys(library.commonPatterns);
        const hasCategories = categories.length > 0;
        
        this.results.library[hasCategories ? 'passed' : 'failed']++;
        this.results.library.tests.push({
            test: 'Categories exist',
            passed: hasCategories,
            categoryCount: categories.length
        });
        
        // Test patterns in each category
        for (const category of categories) {
            const patterns = library.commonPatterns[category].patterns;
            const hasPatterns = patterns && patterns.length > 0;
            
            this.results.library[hasPatterns ? 'passed' : 'failed']++;
            this.results.library.tests.push({
                test: `Patterns in ${category}`,
                passed: hasPatterns,
                patternCount: patterns ? patterns.length : 0
            });
        }
        
        // Test search functionality
        const searchResults = library.searchPatterns('email');
        const hasSearchResults = searchResults.length > 0;
        
        this.results.library[hasSearchResults ? 'passed' : 'failed']++;
        this.results.library.tests.push({
            test: 'Search functionality',
            passed: hasSearchResults,
            resultCount: searchResults.length
        });
        
        // Test custom pattern saving
        library.saveCustomPattern('Test Pattern', 'test\\d+', 'Test description');
        const customPatterns = library.getCustomPatterns();
        const savedSuccessfully = customPatterns.length > 0;
        
        this.results.library[savedSuccessfully ? 'passed' : 'failed']++;
        this.results.library.tests.push({
            test: 'Save custom pattern',
            passed: savedSuccessfully,
            customPatternCount: customPatterns.length
        });
    }

    // Display test results
    displayResults() {
        console.log('\n📊 TEST RESULTS SUMMARY\n' + '='.repeat(50));
        
        let totalPassed = 0;
        let totalFailed = 0;
        
        for (const [feature, results] of Object.entries(this.results)) {
            totalPassed += results.passed;
            totalFailed += results.failed;
            
            const total = results.passed + results.failed;
            const percentage = total > 0 ? (results.passed / total * 100).toFixed(1) : 0;
            const status = results.failed === 0 ? '✅' : '❌';
            
            console.log(`${status} ${feature.toUpperCase()}: ${results.passed}/${total} passed (${percentage}%)`);
            
            // Show failed tests
            if (results.failed > 0) {
                const failedTests = results.tests.filter(t => !t.passed);
                failedTests.forEach(test => {
                    console.log(`   ❌ ${test.pattern || test.test || test.tokenType}: ${test.error || 'Failed'}`);
                });
            }
        }
        
        console.log('='.repeat(50));
        const totalTests = totalPassed + totalFailed;
        const totalPercentage = (totalPassed / totalTests * 100).toFixed(1);
        const overallStatus = totalFailed === 0 ? '🎉' : '⚠️';
        
        console.log(`${overallStatus} TOTAL: ${totalPassed}/${totalTests} passed (${totalPercentage}%)`);
        
        // Return results for programmatic use
        return {
            passed: totalPassed,
            failed: totalFailed,
            total: totalTests,
            percentage: totalPercentage,
            allPassed: totalFailed === 0,
            details: this.results
        };
    }
}

// Auto-run tests if this script is loaded
if (typeof window !== 'undefined') {
    window.addEventListener('load', async () => {
        // Wait a bit for all modules to load
        setTimeout(async () => {
            const tester = new FeatureTester();
            const results = await tester.runAllTests();
            
            // Store results globally for access
            window.testResults = results;
        }, 1000);
    });
}